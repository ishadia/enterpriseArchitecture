/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package section;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author omnia
 */
public class Section {
    
      static  String username="Omnia";
        static String password="omnia14/4";
        static String connectionstring="jdbc:mysql://localhost/Students";
        static Connection con;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        
        // TODO code application logic here
    }
    
}
